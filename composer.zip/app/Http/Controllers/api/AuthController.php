<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        $data = [
            'email' => $request->email,
            'password' => $request->password,
        ];

        $user = User::where('email', $request->email)->get();

        if (count($user) > 0) {
            $user = User::find($user[0]['id']);
            if ($request->verify_code != 'ok') {
                return response()->json(['verification' => 'unverified'], 401);
            } else {
                if (auth()->attempt($data)) {
                    $token = auth()->user()->createToken('ListPlix')->accessToken;
                    return response()->json(['token' => $token], 200);
                } else {
                    return response()->json(['error' => 'unauthorized'], 401);
                }
            }
        }

    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:3|max:50',
            'email' => 'required|email|max:50|unique:users',
            'password' => 'required|min:8|max:16',
            'role' => 'required',
            'department' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        // $verify_code = mt_rand(1000, 9999);
        // $send_mail_details['verify_code'] = $verify_code;
        // $send_mail_details['to'] = $request->email;
        // $send_mail_details['title'] = "Email Verification";
        // $send_mail_details['body'] = "Please verify your email using this code: ";

        // Mail::send('mail', ['send_mail_details' => $send_mail_details], function ($messages) use ($send_mail_details) {
        //     $messages->to($send_mail_details['to']);
        //     $messages->subject($send_mail_details['title']);

        // });
        $code = $this->send_mail($request->email);
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
            'department' => $request->department,
            'verify_code' => $code,
        ]);
        $token = $user->createToken('ListPlix')->accessToken;
        return response()->json(['token' => $token], 200);
    }
    public function send_mail($mail)
    {
        $verify_code = mt_rand(1000, 9999);
        $send_mail_details['verify_code'] = $verify_code;
        $send_mail_details['to'] = $mail;
        $send_mail_details['title'] = "Email Verification";
        $send_mail_details['body'] = "Please verify your email using this code: ";

        Mail::send('mail', ['send_mail_details' => $send_mail_details], function ($messages) use ($send_mail_details) {
            $messages->to($send_mail_details['to']);
            $messages->subject($send_mail_details['title']);

        });
        $user = User::where('email', $mail)->get();

        if (count($user) > 0) {
            $user = User::find($user[0]['id']);
            $db_code = $user->verify_code;
            $user->verify_code = $verify_code;
            $user->save();
        }
        return $verify_code;
    }

    public function user_info()
    {
        $user = auth()->user();
        return response()->json(['user' => $user], 200);
    }
    public function verify_mail(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:50',
            'verify_code' => 'required|max:4',
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        $user = User::where('email', $request->email)->get();

        if (count($user) > 0) {
            $user = User::find($user[0]['id']);
            $db_code = $user->verify_code;
            if ($db_code == $request->verify_code) {
                $user->verify_code = "ok";
                $user->email_verified_at = now()->toDateTimeString();
                $user->save();
                return response()->json(['verification' => 'ok'], 200);
            } else {
                return response()->json(['verification' => 'failed'], 401);
            }
        }
    }
}